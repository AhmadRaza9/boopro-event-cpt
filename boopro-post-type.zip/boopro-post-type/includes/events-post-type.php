<?php
function boopro_post_types()
{

    $labels = array(
        'name' => esc_html_x('Events', 'Post type general name', 'boopro'),
        'singular_name' => esc_html_x('Events Item', 'Post type singular name', 'boopro'),
        'menu_name' => esc_html_x('Events', 'Admin Menu text', 'boopro'),
        'name_admin_bar' => esc_html_x('Events Item', 'Add New on Toolbar', 'boopro'),
        'add_new' => esc_html__('Add New', 'boopro'),
        'add_new_item' => esc_html__('Add New Events Item', 'boopro'),
        'new_item' => esc_html__('New Events Item', 'boopro'),
        'edit_item' => esc_html__('Edit Events Item', 'boopro'),
        'view_item' => esc_html__('View Events Item', 'boopro'),
        'all_items' => esc_html__('All Events Items', 'boopro'),
        'search_items' => esc_html__('Search Events Items', 'boopro'),
        'parent_item_colon' => esc_html__('Parent Events Items:', 'boopro'),
        'not_found' => esc_html__('No Events Item found.', 'boopro'),
        'not_found_in_trash' => esc_html__('No Events Item found in Trash.', 'boopro'),
        'featured_image' => esc_html_x('Events Item Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'boopro'),
        'set_featured_image' => esc_html_x('Set events item image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'boopro'),
        'remove_featured_image' => esc_html_x('Remove events item image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'boopro'),
        'use_featured_image' => esc_html_x('Use as events item image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'boopro'),
        'archives' => esc_html_x('Events archives', 'Events archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'boopro'),
        'insert_into_item' => esc_html_x('Insert into events item', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'boopro'),
        'uploaded_to_this_item' => esc_html_x('Uploaded to this events item', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'boopro'),
        'filter_items_list' => esc_html_x('Filter events item list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'boopro'),
        'items_list_navigation' => esc_html_x('events Item list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'boopro'),
        'items_list' => esc_html_x('Events Items list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'boopro'),
    );
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-calendar-alt',
        'supports' => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        // 'rewrite' => array('slug' => 'portfolio');
    );
    register_post_type('events', $args);

}

add_action('init', 'boopro_post_types');
