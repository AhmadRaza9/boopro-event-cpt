<?php
function boopro_taxonomy()
{
    $labels = array(
        'name' => esc_html_x('Event Type', 'taxonomy general name', 'post-types-firsttheme'),
        'singular_name' => esc_html_x('Event Type', 'taxonomy singular name', 'post-types-firsttheme'),
        'search_items' => esc_html__('Search Event Type', 'post-types-firsttheme'),
        'all_items' => esc_html__('All Event Types', 'post-types-firsttheme'),
        'parent_item' => esc_html__('Parent Event Type', 'post-types-firsttheme'),
        'parent_item_colon' => esc_html__('Parent Event Type:', 'post-types-firsttheme'),
        'edit_item' => esc_html__('Edit Event Type', 'post-types-firsttheme'),
        'update_item' => esc_html__('Update Event Type', 'post-types-firsttheme'),
        'add_new_item' => esc_html__('Add New Event Type', 'post-types-firsttheme'),
        'new_item_name' => esc_html__('New Event Type Name', 'post-types-firsttheme'),
        'menu_name' => esc_html__('Event Types', 'post-types-firsttheme'),
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'show_admin_column' => true,
        // 'rewrite' => array('slug' => 'portfolio');

    );
    register_taxonomy('event_type', ['events'], $args);
}

add_action('init', 'boopro_taxonomy');
