<?php
/*
Plugin Name:  BooPro Post Types
Plugin URI:
Description:  Adding Custom Post Types for BooPro
Version:      1.0.0
Author:       Ahmad Raza
Author URI:   http://ahmadraza.ga/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  boopro-post-types
Domain Path:  /languages
 */

if (!defined('WPINC')) {
    die;
}

include_once "includes/events-post-type.php";
include_once "includes/events-type-tax.php";

function boopro_activate()
{
    boopro_post_types();
    boopro_taxonomy();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'boopro_activate');

function boopro_deactivate()
{
    unregister_post_type('events');
    unregister_taxonomy('event_type');
    flush_rewrite_rules();
}

register_deactivation_hook(__FILE__, 'boopro_deactivate');
